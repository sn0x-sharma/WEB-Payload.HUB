# These are supported funding model platforms

github: # Replace with up to 4 GitHub Sponsors-enabled usernames e.g., [user1, user2]
ko_fi: swissky # Replace with a single Ko-fi username
custom: https://www.buymeacoffee.com/swissky
